---
# You don't need to edit this file, it's empty on purpose.
# Edit theme's home layout instead if you wanna make some changes
# See: https://jekyllrb.com/docs/themes/#overriding-theme-defaults
layout: example
title: "Blogging Like a Hacker"
categories : aaaa
#permalink: /home/
itema: ["<b>alfin  paul</b>","<b>alfin  paul</b>"]
body-class: home home-page
tags : [how-to, jekyll]
---
## hai
```
<b>You’ll find this post in your `_posts` directory. Go ahead and edit it and re-build the site to see your changes. You can rebuild the site in many different ways, but the most common way is to run `jekyll serve`, which launches a web server and auto-regenerates your site when a file is updated.</b>
```

First level header
==================

Second level header
------

Other first level header
-----


This is a normal
paragraph.

And A Header
------------
And a paragraph

> This is a blockquote.

And A Header
------------


# First level header

### Third level header    ###

## Second level header ##



Hello {#a}
-----

# Hello      {#ab}

# Hello #    {#abc}


code

````````````````
aaaaaaa
```````````````

~~~
def what?
  42
end
~~~
{: .language-ruby}

~~~ ruby
def what?
  42
end
~~~

---------
kramdown 
: A Markdown-superset converter
---------

{:#term} Term with id="term"
: {:.cls} Definition with class "cls"

{:#term1} First term
{:#term2} Second term
: {:.cls}{:.cls} Definition


|---
| Default aligned | Left aligned | Center aligned | Right aligned
|---
| First body part | Second cell | Third cell | fourth cell
| Second line |foo | **strong** | baz
| Third line |quux | baz | bar
| Second body
| 2 line
|===
| Footer row


|---
| aaa | bbb
|--- 
| a   | hhh

This is a [link](http://example.com){:hreflang="de"}

[abc]\: There you should find everything you need!

[abc]: http://www.example.com/

This is [a link](http://rubyforge.org) to a page.
A [link](../test "local URI") can also have a title.
And [spaces](spaces.html)!


The next paragraph contains a link and some text.

[Room 100]\: There you should find everything you need!

[Room 100]: link_to_room_100.html



Here is an inline ![smiley](smiley.png){:height="36px" width="36px"}.

And here is a referenced ![smile]

[smile]: smile.png
{: height="36px" width="36px"}


This is a Ruby code fragment `x = Class.new`{:.language-ruby}
