---
title: About-US
layout: home
categories: [sample,jekyll3]
---

This is the base Jekyll theme. You can find out more info about customizing your Jekyll theme, as well as basic Jekyll usage documentation at [jekyllrb.com](http://jekyllrb.com/)

You can find the source code for the Jekyll new theme at:
{% include icon-github.html username="jekyll" %} /
[minima](https://github.com/jekyll/minima)

You can find the source code for Jekyll at
{% include icon-github.html username="jekyll" %} /
[jekyll](https://github.com/jekyll/jekyll)




Here is an inline
![smiley](/static_files/img/logo.jpg) 


And here is a referenced ![smile]

[smile]: https://blog.webjeda.com/images/jekyll-admin-preview-post.png

**{{page.title | upcase }}**

{% for pot in site.posts %}
{{forloop.index}}. {{pot.title}}
{% endfor %}


