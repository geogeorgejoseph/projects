---
title: Sample
layout: example
permalink: /sample/
---

* f
* v
* g
* g
* g