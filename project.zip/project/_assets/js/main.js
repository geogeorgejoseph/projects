//= require jquery.min
//= require jquery-ui
(function($){
  $(document).ready(function(){
   
  });
})(jQuery);
